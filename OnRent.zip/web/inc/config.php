<?php
session_start(); /* Session */
$con=mysqli_connect("localhost","root","","rentalw"); /*Database Connection*/
?>
