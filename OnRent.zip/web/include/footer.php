<!-- Include CSS -->
<link href="./css/bootstrap.min.css" rel="stylesheet"><!-- Bootstrap CSS -->
<link href="./css/style.css" rel="stylesheet"><!-- Custom CSS -->
<!-- Include Google font -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,300,600">
<!-- Include JavaScripts -->
<script src="./js/jquery.min.js" async></script><!-- Load jquery -->
<script src="./js/bootstrap.min.js" async></script><!-- Load bootstrap js -->
<script src="./js/app.js" async></script><!-- Load custom js -->

</body>
</html>
